$('.slider_main').slick({
    autoplay: true,
    arrows: false,
    dots: true,
});

$('.banner_main').slick({
    autoplay: true,
    arrows: false,
    dots: true,
});